#ifndef CHI_IP_DIFFUSION_SOLVER_H
#define CHI_IP_DIFFUSION_SOLVER_H

#include "ChiPhysics/SolverBase/chi_solver.h"

namespace ip_diffusion
{
/** My IP diffusion solver 
 * 
*/
class Solver : public chi_physics::Solver
{
public:
  explicit Solver(const std::string& in_solver_name);

  void Initialize() override;
  void Execute() override;
};

}; // namespace ip_diffusion


#endif // CHI_IP_DIFFUSION_SOLVER_H

