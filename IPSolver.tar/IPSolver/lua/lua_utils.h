#ifndef CHI_IP_DIFFUSION_LUA_UTILS_H
#define CHI_IP_DIFFUSION_LUA_UTILS_H

#include"ChiLua/chi_lua.h"

int chiIPDiffusionSolverCreate(lua_State *L);

#endif // CHI_IP_DIFFUSION_LUA_UTILS_H