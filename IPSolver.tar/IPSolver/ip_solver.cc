#include "ip_solver.h"

#include "chi_runtime.h"
#include "chi_log.h"

ip_diffusion::Solver::Solver(const std::string& in_solver_name):
  chi_physics::Solver(in_solver_name)
{
  
}

void ip_diffusion::Solver::Initialize()
{
  chi::log.Log() << "\nInitiliazing IP solver";
}

void ip_diffusion::Solver::Execute()
{
  chi::log.Log() << "\nExecuting IP solver";
}